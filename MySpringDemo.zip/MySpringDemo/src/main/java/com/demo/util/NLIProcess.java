package com.demo.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;


public class NLIProcess {
    private static final String url = "https://cn.olami.ai/cloudservice/api";
    private static final String Appkey = "fcf20941682b494e9db8c23c14deeb74";
    private static final String Appsecret = "1bcbbe1fb5924185a13c9b5f6d548ee0";
    private static final String api = "nli";    

    private JSONObject process (String input) {
        JSONObject NLIresult = new JSONObject();
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("appkey", Appkey));
        params.add(new BasicNameValuePair("api", api));

        long timestamp = Calendar.getInstance().getTimeInMillis();
        params.add(new BasicNameValuePair("timestamp", String.valueOf(timestamp)));
        params.add(new BasicNameValuePair("sign", generateSign(timestamp)));

        JSONObject request = new JSONObject();
        JSONObject data = new JSONObject();
        try {
            data.put("input_type", 0);
            data.put("text", input);

            request.put("data_type", "stt");
            request.put("data", data);
        } catch (JSONException e1) {
            e1.printStackTrace();
            return NLIresult;
        }
        params.add(new BasicNameValuePair("rq", request.toString()));
        params.add(new BasicNameValuePair("cusid", "asdfghj"));

        CloseableHttpClient httpclient = HttpClients.createDefault();
        HttpPost httppost = new HttpPost(url);
        try {
            httppost.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
            CloseableHttpResponse response = httpclient.execute(httppost);
            try {
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    String contnt = EntityUtils.toString(entity);
                    NLIresult = JSONObject.parseObject(contnt);
                }
            } finally {
                response.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return NLIresult;
        } finally {
            try {
                httpclient.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return NLIresult;
    }

    private String generateSign(long timestamp) {
        String sign = Appsecret + "api=" + api + "appkey=" + Appkey + "timestamp=" + timestamp + Appsecret;
        return MD5String(sign);
    }

    public String MD5String(String str) {
        try {
            MessageDigest msgDigest = MessageDigest.getInstance("MD5");
            msgDigest.reset();
            msgDigest.update(str.getBytes("UTF-8"));
            byte[] byteArrary = msgDigest.digest();
            StringBuffer md5StrBuff = new StringBuffer();
            for (int i = 0; i < byteArrary.length; i++) {
                String tmp = Integer.toHexString(0xFF & byteArrary[i]);
                if (tmp.length() == 1) {
                    md5StrBuff.append(0).append(tmp);
                } else {
                    md5StrBuff.append(tmp);
                }
            }
            return md5StrBuff.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public String getAnswer(String corpus){
		if(corpus != null && !corpus.equals("")){
			JSONObject jsObj = process(corpus);
			return formatJson(jsObj);
		}
		return "请输入正确的语料！";
	}
    
	private static String appendJson(String str, int count) {
        String retStr = "<br>";
        for (int i = 0; i < count; i++) {
            retStr += str;
        }
        return retStr;
    }
	
	/**
	 * 将json转成便于阅读的格式
	 * @param oldJson
	 * @return
	 */
	public static String formatJson(JSONObject old) {
		int i = 0;
		String space = "&nbsp;&nbsp;";
		String formatJson = "";
		int indentCount = 0;
		Boolean isStr = false;
		String currChar = "";

		String oldJson = old.toString();
		
		for (i = 0; i < oldJson.length(); i++) {
			currChar = oldJson.substring(i, i + 1);
			switch (currChar) {
			case "{":
			case "[":
				if (!isStr) {
					indentCount++;
					formatJson += currChar + appendJson(space, indentCount);
				} else {
					formatJson += currChar;
				}
				break;
			case "}":
			case "]":
				if (!isStr) {
					indentCount--;
					formatJson += appendJson(space, indentCount) + currChar;
				} else {
					formatJson += currChar;
				}
				break;
			case ",":
				if (!isStr) {
					formatJson += "," + appendJson(space, indentCount);
				} else {
					formatJson += currChar;
				}
				break;
			case ":":
				if (!isStr) {
					formatJson += ": ";
				} else {
					formatJson += currChar;
				}
				break;
			case " ":
			case "\n":
			case "\t":
				if (isStr) {
					formatJson += currChar;
				}
				break;
			case "\"":
				if (i > 0 && !oldJson.substring(i - 1, i).equals("\\")) {
					isStr = !isStr;
				}
				formatJson += currChar;
				break;
			default:
				formatJson += currChar;
				break;
			}
		}
		return formatJson;
	}

}
