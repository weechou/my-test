package com.demo.controller;

import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.demo.model.CorpusInfo;
import com.demo.util.NLIProcess;


@Controller
@RequestMapping("/")
public class DemoController {

	private NLIProcess nli = new NLIProcess();

	@RequestMapping(method = RequestMethod.GET)
	public String inputCorpus(ModelMap model) {
		CorpusInfo cinfo = new CorpusInfo();
		model.addAttribute("cinfo", cinfo);
		return "enroll";
	}

	@RequestMapping(method=RequestMethod.POST)
	public String nliProcess(@Valid  @ModelAttribute("cinfo") CorpusInfo cinfo,
			BindingResult result, ModelMap model) {

		if (result.hasErrors()) {
			return "enroll";
		}
		model.addAttribute("answer", nli.getAnswer(cinfo.getCorpus()));
		return "success";
	}

}