package funnyGame;

/**
 * 
 * @author Weechou Zhou
 * @since 2018-09-20
 */
public class FunnyGameTest {

	//Main函数， 需求执行的触发入口
	public static void main(String[] args) {
		//runReq1();
		
		runReq2();
	}
		
	/**
	 * req1 :   能够被3整除的数字用Fizz代替，能够被5整除的用Buzz代替，能够被3 or 5整除的被FizzBuzz代替
	 */
	
	public static void runReq1(){
		for(int i =1; i<= 100; i++){
			System.out.println(Rules.getRule(i, false, 3, 5));
		}
	}
	
	/**
	 * req2 :   能够被3整除的数字或包含3的数字用Fizz代替，能够被5整除或包含5的数字用Buzz代替，能够被3 or 5整除，或包含3或5的被FizzBuzz代替
	 */
	public static void runReq2(){
		for(int i =1; i<= 100; i++){
			System.out.println(Rules.getRule(i, true, 3, 5));
		}
	}
}
