package funnyGame;

//规则类

public class Rules {
 
	//定义常量，分别代替3和5的词
	private final static String MES_FIZZ = "Fizz";     
	private final static String MES_BUZZ = "Buzz";
	
	/**
	 * 
	 * @param callNum  当前轮到的应该报的数字
	 * @param checkContained  是否需要判断包含关系
	 * @param fizzNum  用来指定逻辑的需要替换成Fizz的数字
	 * @param buzzNum  用来指定逻辑的需要替换成Buzz的数字
	 * @return
	 */
	public static String getRule(int callNum,boolean checkContained, int fizzNum, int buzzNum){
		String callNumStr = String.valueOf(callNum);
		StringBuffer result = new StringBuffer("");
		
		//当根据fizzNum求余为0，或者如果配置checkContained为true，检查是否包含fizzNum，满足这两种情况，需要替换Fizz
		if(callNum%fizzNum == 0 || (checkContained && callNumStr.contains(String.valueOf(fizzNum)))){
			result.append(MES_FIZZ);
		}
		//当根据buzzNum求余为0，或者如果配置checkContained为true，检查是否包含buzzNum，满足这两种情况，需要替换Buzz
		if(callNum%buzzNum == 0 || (checkContained && callNumStr.contains(String.valueOf(buzzNum)))){
			result.append(MES_BUZZ);
		}
		//如果上述两个逻辑判断以后，result仍然为空，说明上述皆不满足， 则当前报的数字为原数字
		if("".equals(result.toString())){
			result.append(callNumStr);
		}
		
		return result.toString();
	}
}
